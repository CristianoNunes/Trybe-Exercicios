const INITIAL_STATE = [];

function Reducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case 'CADASTRAR':
      return [...state, action.name, action.idade, action.email];
    default:
      return state;
  }
}

export default Reducer;